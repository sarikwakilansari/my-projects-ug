Analysis:

- monthly renewable energy trends
- renewable vs non-renewable comparison ( no data were given)
- energy consumption pattern

To Run:
- Open Notebook
- Run all cells